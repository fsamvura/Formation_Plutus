module Ledger.Typed.TypeUtils
  {-# DEPRECATED "Use Plutus.Script.Utils.V1.Typed.TypeUtils instead" #-}
  ( module Plutus.Script.Utils.V1.Typed.TypeUtils,
  )
where

import Plutus.Script.Utils.V1.Typed.TypeUtils
